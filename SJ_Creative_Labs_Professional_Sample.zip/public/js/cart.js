let cart=[];
function addToCart(p,pr){cart.push({p,pr});localStorage.setItem('cart',JSON.stringify(cart));alert('Added');}
if(document.getElementById('cartData')){
document.getElementById('cartData').value=localStorage.getItem('cart');
}