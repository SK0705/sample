CREATE DATABASE sj_creative_labs;
USE sj_creative_labs;
CREATE TABLE orders(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),company VARCHAR(100),email VARCHAR(100),cart_data TEXT);